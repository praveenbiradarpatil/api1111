package Api;

public class resource {

	 public static String getResource() {
	        String res= "/home_timeline.json";
	        return res;
	    }

	 

	    public static String postResource() {
	        String res= "/update.json";
	        return res;
	    }
	    
	    public static String retweetResource() {
	        String res= "/tweets.json";
	        return res;
	    }
	    public static String getResource1() {
	        String res= "/user_timeline.json";
	        return res;
	
	 }
	    
	    public static String getResource2() {
	        String res= "/place.json";
	        return res;
	    } 
	    public static String postResource2() {
		        String res= "/create.json";
		        return res;
	        
	     }
	    
	    
	    
}

